#include<iostream>
#include<cstdio>
using namespace std;
char a[1000];
int main(){
	while(true){
		gets(a);
		freopen(a,"w",stdout);
	}
}
